import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class ApiService {

    private apiRoot = 'http://127.0.0.1:8000/api/';
  
    constructor(private http: HttpClient) { }
  
  
    getShoppingItems():any {
      return this.http.get(this.apiRoot.concat('shopping-item/'));
    }
  
    createShoppingItem(name: string, quantity: number):any {
      return this.http.post(
        this.apiRoot.concat('shopping-item/'),
        { name, quantity }
      );
    }
  
    deleteShoppingItem(id: number) {
      return this.http.delete(this.apiRoot.concat(`shopping-item/${id}/`));
    }
  }