export interface ShoppingItem {
    id: number;
    name: string;
    quantity: any;
    checked: boolean;
}